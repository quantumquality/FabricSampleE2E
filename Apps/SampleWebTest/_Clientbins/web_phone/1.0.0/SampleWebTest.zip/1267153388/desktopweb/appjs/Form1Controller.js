define("userForm1Controller", {
    //Type your controller code here 
});
define("Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_j5a2a50e787c4b64a2ddf0b9dac59aa3: function AS_Button_j5a2a50e787c4b64a2ddf0b9dac59aa3(eventobject) {
        var self = this;

        function INVOKE_SERVICE_ceb16163756c4ff2a3d24dcc97803063_Callback(status, NewOperation) {}
        if (NewOperation_inputparam == undefined) {
            var NewOperation_inputparam = {};
        }
        NewOperation_inputparam["serviceID"] = "Mockservice$NewOperation";
        var NewOperation_httpheaders = {};
        NewOperation_inputparam["httpheaders"] = NewOperation_httpheaders;
        var NewOperation_httpconfigs = {};
        NewOperation_inputparam["httpconfig"] = NewOperation_httpconfigs;
        Mockservice$NewOperation = mfintegrationsecureinvokerasync(NewOperation_inputparam, "Mockservice", "NewOperation", INVOKE_SERVICE_ceb16163756c4ff2a3d24dcc97803063_Callback);
    },
    AS_Button_b8f98bdb29c14974acf2ce37b53beaef: function AS_Button_b8f98bdb29c14974acf2ce37b53beaef(eventobject) {
        var self = this;
        this.view.Label0f3d801f4272147.text = "button clicked";
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
