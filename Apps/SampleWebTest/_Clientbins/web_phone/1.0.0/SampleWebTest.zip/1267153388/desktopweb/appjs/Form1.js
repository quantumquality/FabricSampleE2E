define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(kony.flex.DP);
            var Button0b7e9f963f7ce45 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0b7e9f963f7ce45",
                "isVisible": true,
                "left": "284dp",
                "onClick": controller.AS_Button_b8f98bdb29c14974acf2ce37b53beaef,
                "skin": "defBtnNormal",
                "text": "Button",
                "top": "97dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0f3d801f4272147 = new kony.ui.Label({
                "id": "Label0f3d801f4272147",
                "isVisible": true,
                "left": "339dp",
                "skin": "defLabel",
                "text": "Label",
                "top": "235dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0a5ee126e5ef145 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0a5ee126e5ef145",
                "isVisible": true,
                "left": "142dp",
                "onClick": controller.AS_Button_j5a2a50e787c4b64a2ddf0b9dac59aa3,
                "skin": "defBtnNormal",
                "text": "inVoke service",
                "top": "365dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0id157bd9c24944 = new kony.ui.Label({
                "id": "Label0id157bd9c24944",
                "isVisible": true,
                "left": "230dp",
                "skin": "defLabel",
                "text": "Label",
                "top": "570dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0ed2424be73de4c = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0ed2424be73de4c",
                "isVisible": true,
                "left": "419dp",
                "skin": "defBtnNormal",
                "text": "Button",
                "top": "574dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Button0b7e9f963f7ce45, Label0f3d801f4272147, Button0a5ee126e5ef145, Label0id157bd9c24944, Button0ed2424be73de4c);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "SampleWebTest"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});