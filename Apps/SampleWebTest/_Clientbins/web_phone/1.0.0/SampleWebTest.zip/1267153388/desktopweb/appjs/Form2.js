define("Form2", function() {
    return function(controller) {
        function addWidgetsForm2() {
            this.setDefaultUnit(kony.flex.DP);
            var Segment0c88d2052644a4f = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }, {
                    "lblDescription": "Sub-Heading",
                    "lblHeading": "Heading",
                    "lblStrip": "",
                    "lblTime": "Timestamp"
                }],
                "groupCells": false,
                "height": "240dp",
                "id": "Segment0c88d2052644a4f",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSampleRowTemplate",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "80dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSampleRowTemplate": "flxSampleRowTemplate",
                    "lblDescription": "lblDescription",
                    "lblHeading": "lblHeading",
                    "lblStrip": "lblStrip",
                    "lblTime": "lblTime"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SampleWebTest"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Segment0c88d2052644a4f);
        };
        return [{
            "addWidgets": addWidgetsForm2,
            "enabledForIdleTimeout": false,
            "id": "Form2",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "SampleWebTest"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});